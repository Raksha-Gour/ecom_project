var express=require("express");
var app=express();
var cors=require("cors");
app.use(cors());
var multer=require("multer");
var upload=multer();
var bcrypt=require("bcrypt");
var jwt=require("jsonwebtoken");
var verify=require("../backend/middleware/verify.js");
// const dbConnect = require("../dbConfig/config");


const { MongoClient } = require("mongodb");
async function dbConnect(collection){
    var url="mongodb://127.0.0.1:27017";
    var client = new MongoClient(url);
    var connect = client.db("Practice");
        if(collection=="orders"){
            var collection = connect.collection("orders");
            return collection;
            }
            else{
            var collection = connect.collection("User");
            return collection;
            }
    
}

app.get("/",function(req,res){
    var name="Raksha";
    res.send({message:"Hello everyone",name:name});
});

app.get("/users",function(req,res){
    var name="Raksha";
    var email="xyz@gmail.com";
    res.send({message:"Hello users",name:name,email:email});
});

app.post("/register",upload.single(), async function(req,res){
    const{name,email,password,confirm_password,address}=req.body;
    console.log("name,email,password,confirm_password,address",name,email,password,confirm_password,address);
    if(name&&email&&password&&confirm_password&&address){
        if(password==confirm_password){
            var user= await dbConnect();
            var hashPassword=await bcrypt.hash(password,10);
            console.log("hashpassword=",hashPassword);
            var findUser =await user.findOne({email:email});
            if(findUser){   
                res.send({message:"user already register",status:1}); 
            }
            else{
                var insertData = await user.insertOne({
                    name:name,
                    email:email,
                    address:address,
                    password:hashPassword,
                    confirm_password:confirm_password,
                    status:1 //by default active=1
                })
                if(insertData){
                    res.send({message:"Registration successfully",status:1});
                }
                else{
               
                res.send({message:"Registration failed",status:0});
            }
               }
         }
        else{
            res.send({message:"password is not match",status:0});
        }
    }
    else{
          res.send({message:"name, email,password,confirm_password not be empty",status:0});
       }
});

app.post("/login",upload.single(),async function(req,res){
    const email=req.body.email;
    const password=req.body.password;
    if(email&&password){
        const user=await dbConnect();
        const findUser=await user.findOne({email:email});
        if(findUser){
            if((findUser.email==email)){
                    bcrypt.compare(password,findUser.password, async function(error,result){
                    console.log("result=",result);
                    console.log("error=",error);
                    if(result){
                        const token= jwt.sign({email:findUser.email},"Private_key",{expiresIn:"50min",algorithm:"HS256"});
                        console.log("token=",token);
                        const updateUser=await user.updateOne({email},{$set:{token:token}});
                        res.send({message:"login successfully", status:1,token:token,email:email,data: updateUser});
                        
                 }
                 else{
                    res.send({message:"please enter valid password", status:0});
                    }
              })
             }
            else{
                res.send({message:"login failed",status:0});
             }
        }
        else{
             res.send({message:"user not found", status:0});
    }
}
    else{
        res.send({message:"email and password not empty",status:0});
    }
});
    
app.listen(8000,function(){
    console.log("Server running on http://localhost:8000");
});